# AI Dropshipping Minimal

This is a minimal Next.js project ready for Vercel deployment.

## Run locally
1. Install dependencies:
   npm install
2. Run dev server:
   npm run dev
3. Open http://localhost:3000