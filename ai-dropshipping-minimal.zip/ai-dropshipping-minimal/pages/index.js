export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>AI Dropshipping Platform</h1>
      <p>Welcome! Your minimal Next.js app is running successfully.</p>
    </div>
  );
}